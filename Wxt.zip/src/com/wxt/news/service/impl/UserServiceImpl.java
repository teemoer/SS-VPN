package com.wxt.news.service.impl;

import com.wxt.news.entity.User;
import com.wxt.news.repository.UserDao;
import com.wxt.news.service.UserService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * Created by teemoer@cntv.cn on 2016/7/3 0003.
 */
@Service("userService")
public class UserServiceImpl implements UserService {
    @Resource
    private UserDao userDao;

    @Override
    public Page<User> getUserList(Pageable pageable) {
        return userDao.findAll(pageable);
    }

    @Override
    public User getUserByNameAndPwd(String name, String pwd) {
        return userDao.findUserByUserNameAndPassword(name, pwd);
    }

    @Override
    public void saveOrUpdate(User user) {

        userDao.save(user);
    }

    @Override
    public User getUserById(Long id) {
        return userDao.findUserById(id);
    }

    @Override
    public void saveUser(User user) {
        userDao.saveAndFlush(user);
    }

    @Override
    public void delUserById(Long id) {
        userDao.delete(id);
    }
}
