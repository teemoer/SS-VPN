package com.wxt.news.entity;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by teemoer@cntv.cn on 2016/7/3 0003.
 */
@Entity
@Table(name = "news")
@DynamicInsert(true)
@DynamicUpdate(true)
public class News extends IdEntity {

	// Fields

	private String title;
	private String author;
	private String content;
	private String keyWords;
	private Timestamp submitDate;
	private String picture;
	private String video;
	private Set<Messages> messageses = new HashSet<Messages>(0);

	// Constructors

	/** default constructor */
	public News() {
	}

	/** minimal constructor */
	public News(String title, String author, String content, String keyWords,
			Timestamp submitDate) {
		this.title = title;
		this.author = author;
		this.content = content;
		this.keyWords = keyWords;
		this.submitDate = submitDate;
	}

	/** full constructor */
	public News(String title, String author, String content, String keyWords,
			Timestamp submitDate, String picture, String video,
			Set<Messages> messageses) {
		this.title = title;
		this.author = author;
		this.content = content;
		this.keyWords = keyWords;
		this.submitDate = submitDate;
		this.picture = picture;
		this.video = video;
		this.messageses = messageses;
	}



	@Column(name = "title", nullable = false, length = 100)
	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Column(name = "author", nullable = false, length = 80)
	public String getAuthor() {
		return this.author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Column(name = "content", nullable = false, length = 65535)
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Column(name = "key_words", nullable = false, length = 100)
	public String getKeyWords() {
		return this.keyWords;
	}

	public void setKeyWords(String keyWords) {
		this.keyWords = keyWords;
	}

	@Column(name = "submit_date", nullable = false, length = 19)
	public Timestamp getSubmitDate() {
		return this.submitDate;
	}

	public void setSubmitDate(Timestamp submitDate) {
		this.submitDate = submitDate;
	}

	@Column(name = "picture", length = 100)
	public String getPicture() {
		return this.picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	@Column(name = "video", length = 100)
	public String getVideo() {
		return this.video;
	}

	public void setVideo(String video) {
		this.video = video;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "news")
	public Set<Messages> getMessageses() {
		return this.messageses;
	}

	public void setMessageses(Set<Messages> messageses) {
		this.messageses = messageses;
	}

}