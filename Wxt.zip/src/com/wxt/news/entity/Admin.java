package com.wxt.news.entity;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by teemoer@cntv.cn on 2016/7/3 0003.
 */
@Entity
@Table(name = "admin")
@DynamicInsert(true)
@DynamicUpdate(true)
public class Admin extends IdEntity {

    // Fields

    private String type;
    private String name;
    private String loginName;
    private String loginPwd;
    private Set<User> userses = new HashSet<User>(0);

    // Constructors

    /**
     * default constructor
     */
    public Admin() {
    }

    /**
     * minimal constructor
     */
    public Admin(String type, String name, String loginName, String loginPwd) {
        this.type = type;
        this.name = name;
        this.loginName = loginName;
        this.loginPwd = loginPwd;
    }

    /**
     * full constructor
     */
    public Admin(String type, String name, String loginName, String loginPwd,
                 Set<User> userses) {
        this.type = type;
        this.name = name;
        this.loginName = loginName;
        this.loginPwd = loginPwd;
        this.userses = userses;
    }


    @Column(name = "type", nullable = false, length = 80)
    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Column(name = "name", nullable = false, length = 80)
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "login_name", nullable = false, length = 80)
    public String getLoginName() {
        return this.loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    @Column(name = "login_pwd", nullable = false, length = 80)
    public String getLoginPwd() {
        return this.loginPwd;
    }

    public void setLoginPwd(String loginPwd) {
        this.loginPwd = loginPwd;
    }

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "admin")
    public Set<User> getUserses() {
        return this.userses;
    }

    public void setUserses(Set<User> userses) {
        this.userses = userses;
    }

}