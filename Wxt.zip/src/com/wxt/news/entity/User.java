package com.wxt.news.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by teemoer@cntv.cn on 2016/7/3 0003.
 */
@Entity
@Table(name = "user")
public class User extends IdEntity {

    private Admin admin;
    private String userName;
    private String password;
    private String email;
    private String hobby;
    private String adderss;
    private Date brithday;
    private String picture;
    private String gender;
    private Set<Messages> messageses = new HashSet<Messages>(0);

    // Constructors

    /**
     * default constructor
     */
    public User() {
    }

    /**
     * minimal constructor
     */
    public User(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    /**
     * full constructor
     */
    public User(Admin admin, String userName, String password, String email,
                String hobby, String adderss, Date brithday, String picture,
                String gender, Set<Messages> messageses) {
        this.admin = admin;
        this.userName = userName;
        this.password = password;
        this.email = email;
        this.hobby = hobby;
        this.adderss = adderss;
        this.brithday = brithday;
        this.picture = picture;
        this.gender = gender;
        this.messageses = messageses;
    }


    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "admin_id")
    @JsonIgnore
    public Admin getAdmin() {
        return this.admin;
    }

    public void setAdmin(Admin admin) {
        this.admin = admin;
    }

    @Column(name = "user_name", nullable = false, length = 100)
    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Column(name = "password", nullable = false, length = 100)
    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Column(name = "email", length = 100)
    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Column(name = "hobby", length = 100)
    public String getHobby() {
        return this.hobby;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

    @Column(name = "adderss", length = 100)
    public String getAdderss() {
        return this.adderss;
    }

    public void setAdderss(String adderss) {
        this.adderss = adderss;
    }

    @Temporal(TemporalType.DATE)
    @Column(name = "brithday", length = 10)
    public Date getBrithday() {
        return this.brithday;
    }

    public void setBrithday(Date brithday) {
        this.brithday = brithday;
    }

    @Column(name = "picture", length = 100)
    public String getPicture() {
        return this.picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    @Column(name = "gender", length = 20)
    public String getGender() {
        return this.gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "user")
    @JsonIgnore
    public Set<Messages> getMessageses() {
        return this.messageses;
    }

    public void setMessageses(Set<Messages> messageses) {
        this.messageses = messageses;
    }
}
