package com.wxt.news.controller;

import com.wxt.news.entity.Admin;
import com.wxt.news.entity.User;
import com.wxt.news.service.AdminService;
import com.wxt.news.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

/**
 * Created by teemoer@cntv.cn on 2016/7/2 0002.
 */
@Controller
public class LoginController {
    @Resource
    private UserService userService;

    @Resource
    AdminService adminService;


    /**
     * 跳转到后台登录页面
     *
     * @return
     */
    @RequestMapping(value = "/admin/login")
    public String goToAdminLogin() {

        return "/admin/login";
    }

    @RequestMapping(value = "/admin/loginChack")
    public String adminLoginChack(@RequestParam("name") String name, @RequestParam(value = "pwd") String pwd, Model model) {
        String msg = "登录失败,用户名或者密码错误!";
        try {
            Admin admin = adminService.getAdminByNameAndPwd(name, pwd);
            //如果有这个用户 就跳转到后台首页
            if (admin != null) {
                return "/admin/index";
            }
        } catch (Exception e) {
            msg = "出现错误!";
        }

        //成功没 admin用户 那么说明用户名或者密码错误 就跳转到 后台登录页面
        model.addAttribute("error", msg);
        return "/admin/login";
    }


    @RequestMapping(value = "/web/loginChack")
    public String webLoginChack(@RequestParam("userName") String name, @RequestParam(value = "password") String pwd, Model model,
                                HttpSession session) {
        String msg = "登录失败,用户名或者密码错误!";
        try {
            User user = userService.getUserByNameAndPwd(name, pwd);
            //如果有这个用户 就跳转到后台首页
            if (user != null) {
                //将用户信息放到session中
                session.setAttribute("isLogin", true);
                session.setAttribute("user", user);
                return "/web/index";
            }
        } catch (Exception e) {
            msg = "出现错误!";
        }

        //成功没 user用户 那么说明用户名或者密码错误 就跳转到 后台登录页面
        model.addAttribute("error", msg);
        return "/web/login";
    }

    @RequestMapping(value = "/loginOut")
    public String loginOut(HttpSession session) {
        String msg = "登录失败,用户名或者密码错误!";
        session.setAttribute("isLogin", false);
        session.setAttribute("user", null);
        return "/web/index";
    }

    @RequestMapping(value = "/web/head")
    public String getHead() {
        return "/web/layout/header";
    }


    /**
     * 跳转到普通用户登录页面
     *
     * @return
     */
    @RequestMapping(value = "/login")
    public String goToLogin() {
        return "/web/login";
    }

    /**
     * 跳转到普通用户登录页面
     *
     * @return
     */
    @RequestMapping(value = "/register")
    public String goToRegister() {
        return "/web/register";
    }



    /**
     * 跳转到前台首页
     *
     * @return
     */
    @RequestMapping(value = "/index")
    public String goToIndex() {
        return "/web/index";
    }


}
