package com.wxt.news.controller;

import com.wxt.news.entity.Messages;
import com.wxt.news.service.MessagesService;
import com.wxt.news.support.Result;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.Date;

/**
 * Created by teemoer@cntv.cn on 2016/7/3 0003.
 */
@Controller
public class MessagesController {
    @Resource
    private MessagesService messagesService;

    @RequestMapping(value = "/messagesList", method = {RequestMethod.GET})
    public String getUserListGet(@RequestParam(value = "page", defaultValue = "0") int page, Model model) {
        Pageable pageable = new PageRequest(page, 2, Sort.Direction.DESC, "id");
        Page<Messages> messages = messagesService.getMessagesList(pageable);

        model.addAttribute("messages", messages);
        model.addAttribute("nowPage", page + 1);

        return "/admin/messageEdit/index";
    }


    @RequestMapping(value = "/messages/addMessages", method = {RequestMethod.POST})
    public String addMessages(@RequestParam(value = "userName") String userName,
                              @RequestParam(value = "email") String email,
                              @RequestParam(value = "password") String password,
                              @RequestParam(value = "address") String address,
                              @RequestParam() @DateTimeFormat(pattern = "YYYY-MM-dd") Date birthday,
                              @RequestParam(value = "hobby") String[] hobby,
                              @RequestParam(value = "gender") String gender,
                              HttpSession session) {
        Messages messages = new Messages();

        messagesService.saveOrUpdate(messages);


        return "/admin/messageEdit/edit";
    }

    @RequestMapping(value = "/messages/edit", method = {RequestMethod.GET})
    public String userEdit(@RequestParam(value = "id") Long id, Model model) {
        Messages messages = messagesService.getUserById(id);
        model.addAttribute("messages", messages);

        return "/admin/messageEdit/edit";
    }

    @RequestMapping(value = "/messages/save")
    public String userSave(@ModelAttribute Messages messages, Model model) {

        messagesService.saveOrUpdate(messages);
        model.addAttribute("msg", "保存成功!");
        return "/admin/messageEdit/edit";
    }

    @RequestMapping(value = "/messages/delMessages")
    @ResponseBody
    public Result delUser(@RequestParam(value = "id") Long id) {

        messagesService.delUserById(id);
        return Result.ok();
    }
}
